# Komal Accessories — E-Commerce Store & Admin Portal

A boutique e-commerce web application with a live Store Manager (Admin Portal) for teen hair accessories, cute jewelry, trendy adult pieces, baby care, and luxury gift hampers with real-time order tracking and secure checkout.

## 🚀 Getting Started

### 1. Install Dependencies
```bash
npm install
```

### 2. Run Development Server
```bash
npm run dev
```
Open `http://localhost:3000` or `http://localhost:5173` in your browser.

### 3. Build for Production
```bash
npm run build
```

---

## 🛠️ Store Manager (Admin Portal)
- Access the Admin Portal by clicking the **"Admin / Manager"** button in the header or the **"Store Manager Portal"** link in the footer.
- **Default Passcode**: `admin123` (or click "1-Click Store Owner Login").
- Features:
  - Add & edit products with image replacement and instant rate changes.
  - Add & manage categories (automatically synced to store navigation and filter buttons).
  - Manage customer orders with live status stepping (*Placed* -> *Packed* -> *Dispatched* -> *Out for Delivery* -> *Delivered*).
  - Customer WhatsApp direct messaging with order details.
  - Printable packing slip & invoice generation.
  - Promo coupons creation and management.
  - Store settings & shipping rates customization.

---

## 📦 How to Push to GitHub

If you downloaded the ZIP file and want to connect it to your GitHub repository:

```bash
# 1. Unzip the file and open the folder in terminal
cd komal-accessories

# 2. Initialize git (if not already initialized)
git init

# 3. Add all files
git add .

# 4. Commit changes
git commit -m "feat: complete Komal Accessories storefront and admin portal"

# 5. Link to your GitHub repository (replace with your repo URL)
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git

# 6. Push to main branch
git branch -M main
git push -u origin main
```

---

## 💻 Tech Stack
- **Framework**: React 19 + TypeScript
- **Bundler**: Vite
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Animations**: Motion
