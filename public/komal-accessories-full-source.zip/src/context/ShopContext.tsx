import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Product, 
  CartItem, 
  Order, 
  ProductCategory, 
  CategoryItem, 
  Coupon, 
  StoreSettings, 
  OrderStatus 
} from '../types';
import { PRODUCTS } from '../data/products';
import { DEFAULT_CATEGORIES, DEFAULT_COUPONS, DEFAULT_STORE_SETTINGS } from '../data/categories';

interface ShopContextType {
  // Products Management
  products: Product[];
  addProduct: (productData: Omit<Product, 'id'>) => Product;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;

  // Categories Management
  categories: CategoryItem[];
  addCategory: (cat: CategoryItem) => void;
  updateCategory: (id: string, label: string, description?: string) => void;
  deleteCategory: (id: string) => void;

  // Store Settings & Info
  storeSettings: StoreSettings;
  updateStoreSettings: (settings: Partial<StoreSettings>) => void;
  resetToDefaults: () => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, selectedColor?: string) => void;
  removeFromCart: (productId: string, selectedColor: string) => void;
  updateQuantity: (productId: string, selectedColor: string, newQty: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  
  // Coupons & Discounts
  coupons: Coupon[];
  appliedCoupon: string | null;
  discountAmount: number;
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  addCoupon: (coupon: Coupon) => void;
  toggleCoupon: (code: string) => void;
  deleteCoupon: (code: string) => void;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Orders & Tracking
  orders: Order[];
  placeOrder: (orderInfo: {
    customerName: string;
    email: string;
    phone: string;
    city: string;
    address: string;
    postalCode?: string;
    notes?: string;
    paymentMethod: 'cod' | 'card' | 'jazzcash_easypaisa';
  }) => Order;
  getOrderById: (query: string) => Order | undefined;
  updateOrderStatus: (orderId: string, status: OrderStatus, courierName?: string, trackingNumber?: string) => void;
  deleteOrder: (orderId: string) => void;
  trackOrderId: string;
  setTrackOrderId: (id: string) => void;

  // Navigation & Modals
  activeCategory: ProductCategory;
  setActiveCategory: (cat: ProductCategory) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  activeProduct: Product | null;
  setActiveProduct: (p: Product | null) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isWishlistOpen: boolean;
  setIsWishlistOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  isTrackOrderOpen: boolean;
  setIsTrackOrderOpen: (open: boolean) => void;
  openOrderTrackerWithId: (orderId?: string) => void;

  // Admin Portal State
  isAdminMode: boolean;
  setIsAdminMode: (active: boolean) => void;
  isAdminAuthenticated: boolean;
  isAdminLoginOpen: boolean;
  setIsAdminLoginOpen: (open: boolean) => void;
  loginAdmin: (passcode: string) => boolean;
  logoutAdmin: () => void;
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

// Initial demo order for instant tracking test
const INITIAL_DEMO_ORDER: Order = {
  id: 'KA-84920',
  trackingNumber: 'TRX-94827104PK',
  customerName: 'Aiman Zahra',
  email: 'aiman.zahra@example.com',
  phone: '0302-8472910',
  city: 'Lahore',
  address: 'House #42, Block D, Model Town',
  postalCode: '54700',
  notes: 'Please ring bell twice, call before delivery.',
  items: [
    {
      product: PRODUCTS[0],
      quantity: 1,
      selectedColor: 'Lilac Shimmer',
    },
    {
      product: PRODUCTS[1],
      quantity: 1,
      selectedColor: 'Pure White Shell',
    },
  ],
  subtotal: 2100,
  shipping: 0,
  discount: 210,
  total: 1890,
  paymentMethod: 'cod',
  paymentStatus: 'pending',
  courierName: 'Trax Express Logistics',
  orderStatus: 'out_for_delivery',
  createdAt: '28 Sep 2026, 02:40 PM',
  estimatedDelivery: 'Today by 5:00 PM',
  timeline: [
    {
      status: 'placed',
      label: 'Order Placed & Confirmed',
      description: 'Your order was verified by Komal Customer Care.',
      timestamp: '28 Sep 2026, 02:45 PM',
      completed: true,
      current: false,
    },
    {
      status: 'packed',
      label: 'Quality Checked & Gift Packed',
      description: 'Items wrapped in blush tissue and satin gift ribbon with seal.',
      timestamp: '28 Sep 2026, 05:10 PM',
      completed: true,
      current: false,
    },
    {
      status: 'dispatched',
      label: 'Dispatched via Trax Express',
      description: 'Handed over to Trax Central Hub Lahore (Waybill # TRX-94827104PK).',
      timestamp: '29 Sep 2026, 09:15 AM',
      completed: true,
      current: false,
    },
    {
      status: 'out_for_delivery',
      label: 'Out for Delivery in Lahore',
      description: 'Courier Rider (Hamza Ali, Contact: 0312-9847162) is on the way.',
      timestamp: '29 Sep 2026, 11:30 AM',
      completed: true,
      current: true,
    },
    {
      status: 'delivered',
      label: 'Delivered & Signed',
      description: 'Package handed over and payment received upon delivery.',
      timestamp: 'Estimated: Today, 04:30 PM',
      completed: false,
      current: false,
    },
  ],
};

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Products state (stored in localStorage, connected to both storefront and admin)
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('komal_products');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      return PRODUCTS;
    } catch {
      return PRODUCTS;
    }
  });

  // Categories state
  const [categories, setCategories] = useState<CategoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('komal_categories');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      return DEFAULT_CATEGORIES;
    } catch {
      return DEFAULT_CATEGORIES;
    }
  });

  // Coupons state
  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    try {
      const saved = localStorage.getItem('komal_coupons');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      return DEFAULT_COUPONS;
    } catch {
      return DEFAULT_COUPONS;
    }
  });

  // Store Settings state
  const [storeSettings, setStoreSettings] = useState<StoreSettings>(() => {
    try {
      const saved = localStorage.getItem('komal_settings');
      if (saved) return JSON.parse(saved);
      return DEFAULT_STORE_SETTINGS;
    } catch {
      return DEFAULT_STORE_SETTINGS;
    }
  });

  // Cart state persisted in localStorage
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('komal_cart');
      return saved ? JSON.parse(saved) : [
        {
          product: PRODUCTS[0],
          quantity: 1,
          selectedColor: PRODUCTS[0].colors[0]?.name || 'Standard',
        }
      ];
    } catch {
      return [];
    }
  });

  // Wishlist state persisted in localStorage
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('komal_wishlist');
      return saved ? JSON.parse(saved) : ['ka-jewel-01', 'ka-gift-01'];
    } catch {
      return ['ka-jewel-01'];
    }
  });

  // Orders state
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('komal_orders');
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.length > 0 ? parsed : [INITIAL_DEMO_ORDER];
      }
      return [INITIAL_DEMO_ORDER];
    } catch {
      return [INITIAL_DEMO_ORDER];
    }
  });

  // Coupon state
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);

  // Modals & Navigation state
  const [activeCategory, setActiveCategory] = useState<ProductCategory>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState<boolean>(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [isTrackOrderOpen, setIsTrackOrderOpen] = useState<boolean>(false);
  const [trackOrderId, setTrackOrderId] = useState<string>('KA-84920');

  // Admin Portal State
  const [isAdminMode, setIsAdminMode] = useState<boolean>(() => {
    try {
      return localStorage.getItem('komal_admin_mode') === 'true';
    } catch {
      return false;
    }
  });

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    try {
      return localStorage.getItem('komal_admin_auth') === 'true';
    } catch {
      return false;
    }
  });

  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('komal_products', JSON.stringify(products));
    } catch {}
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem('komal_categories', JSON.stringify(categories));
    } catch {}
  }, [categories]);

  useEffect(() => {
    try {
      localStorage.setItem('komal_coupons', JSON.stringify(coupons));
    } catch {}
  }, [coupons]);

  useEffect(() => {
    try {
      localStorage.setItem('komal_settings', JSON.stringify(storeSettings));
    } catch {}
  }, [storeSettings]);

  useEffect(() => {
    try {
      localStorage.setItem('komal_cart', JSON.stringify(cart));
    } catch {}
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('komal_wishlist', JSON.stringify(wishlist));
    } catch {}
  }, [wishlist]);

  useEffect(() => {
    try {
      localStorage.setItem('komal_orders', JSON.stringify(orders));
    } catch {}
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem('komal_admin_auth', isAdminAuthenticated ? 'true' : 'false');
      localStorage.setItem('komal_admin_mode', isAdminMode ? 'true' : 'false');
    } catch {}
  }, [isAdminAuthenticated, isAdminMode]);

  // Admin Authentication
  const loginAdmin = (passcode: string): boolean => {
    const clean = passcode.trim();
    if (clean === 'admin123' || clean === 'komal' || clean === 'admin' || clean === '1234') {
      setIsAdminAuthenticated(true);
      setIsAdminMode(true);
      setIsAdminLoginOpen(false);
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    setIsAdminAuthenticated(false);
    setIsAdminMode(false);
  };

  // Products CRUD
  const addProduct = (productData: Omit<Product, 'id'>): Product => {
    const newId = `ka-item-${Date.now()}`;
    const newProduct: Product = {
      ...productData,
      id: newId,
    };
    setProducts((prev) => [newProduct, ...prev]);
    return newProduct;
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          const updated = { ...p, ...updates };
          // If activeProduct is currently this one, update it too
          if (activeProduct && activeProduct.id === id) {
            setActiveProduct(updated);
          }
          return updated;
        }
        return p;
      })
    );

    // Also update in cart if present
    setCart((prev) =>
      prev.map((item) => {
        if (item.product.id === id) {
          return {
            ...item,
            product: { ...item.product, ...updates },
          };
        }
        return item;
      })
    );
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    setCart((prev) => prev.filter((item) => item.product.id !== id));
    setWishlist((prev) => prev.filter((pId) => pId !== id));
    if (activeProduct && activeProduct.id === id) {
      setActiveProduct(null);
    }
  };

  // Categories CRUD
  const addCategory = (newCat: CategoryItem) => {
    setCategories((prev) => [...prev, newCat]);
  };

  const updateCategory = (id: string, label: string, description?: string) => {
    setCategories((prev) =>
      prev.map((c) => (c.id === id ? { ...c, label, description: description || c.description } : c))
    );
  };

  const deleteCategory = (id: string) => {
    if (id === 'all') return; // Cannot delete 'all'
    setCategories((prev) => prev.filter((c) => c.id !== id));
    // If activeCategory is deleted, reset to 'all'
    if (activeCategory === id) {
      setActiveCategory('all');
    }
  };

  // Coupons CRUD
  const addCoupon = (coupon: Coupon) => {
    setCoupons((prev) => [coupon, ...prev.filter((c) => c.code !== coupon.code)]);
  };

  const toggleCoupon = (code: string) => {
    setCoupons((prev) =>
      prev.map((c) => (c.code === code ? { ...c, isActive: !c.isActive } : c))
    );
  };

  const deleteCoupon = (code: string) => {
    setCoupons((prev) => prev.filter((c) => c.code !== code));
    if (appliedCoupon === code) {
      setAppliedCoupon(null);
    }
  };

  // Store Settings CRUD
  const updateStoreSettings = (updates: Partial<StoreSettings>) => {
    setStoreSettings((prev) => ({ ...prev, ...updates }));
  };

  const resetToDefaults = () => {
    setProducts(PRODUCTS);
    setCategories(DEFAULT_CATEGORIES);
    setCoupons(DEFAULT_COUPONS);
    setStoreSettings(DEFAULT_STORE_SETTINGS);
    setOrders([INITIAL_DEMO_ORDER]);
    try {
      localStorage.removeItem('komal_products');
      localStorage.removeItem('komal_categories');
      localStorage.removeItem('komal_coupons');
      localStorage.removeItem('komal_settings');
      localStorage.removeItem('komal_orders');
    } catch {}
  };

  // Cart operations
  const addToCart = (product: Product, quantity = 1, selectedColor?: string) => {
    const color = selectedColor || product.colors[0]?.name || 'Standard';
    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex(
        (item) => item.product.id === product.id && item.selectedColor === color
      );
      if (existingIndex > -1) {
        const updated = [...prevCart];
        updated[existingIndex].quantity += quantity;
        return updated;
      } else {
        return [...prevCart, { product, quantity, selectedColor: color }];
      }
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string, selectedColor: string) => {
    setCart((prev) =>
      prev.filter(
        (item) => !(item.product.id === productId && item.selectedColor === selectedColor)
      )
    );
  };

  const updateQuantity = (productId: string, selectedColor: string, newQty: number) => {
    if (newQty <= 0) {
      removeFromCart(productId, selectedColor);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (item.product.id === productId && item.selectedColor === selectedColor) {
          return { ...item, quantity: newQty };
        }
        return item;
      })
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  // Dynamic coupon calculation based on coupons list
  const activeCouponObj = coupons.find((c) => c.code === appliedCoupon && c.isActive);

  let discountAmount = 0;
  if (activeCouponObj) {
    if (activeCouponObj.discountType === 'percentage') {
      discountAmount = Math.round(cartSubtotal * (activeCouponObj.discountValue / 100));
    } else {
      discountAmount = activeCouponObj.discountValue;
    }
  }

  const applyCoupon = (code: string) => {
    const trimmed = code.trim().toUpperCase();
    const found = coupons.find((c) => c.code.toUpperCase() === trimmed);
    if (!found) {
      return { success: false, message: 'Invalid coupon code.' };
    }
    if (!found.isActive) {
      return { success: false, message: 'This coupon has expired or is currently inactive.' };
    }
    if (cartSubtotal < found.minOrderValue) {
      return {
        success: false,
        message: `This coupon requires a minimum cart total of Rs. ${found.minOrderValue.toLocaleString()}.`,
      };
    }

    setAppliedCoupon(found.code);
    return { 
      success: true, 
      message: `🎉 Coupon applied: ${found.discountType === 'percentage' ? `${found.discountValue}% Off` : `Rs. ${found.discountValue} Off`}` 
    };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
  };

  // Wishlist operations
  const toggleWishlist = (productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  // Place Order
  const placeOrder = (orderInfo: {
    customerName: string;
    email: string;
    phone: string;
    city: string;
    address: string;
    postalCode?: string;
    notes?: string;
    paymentMethod: 'cod' | 'card' | 'jazzcash_easypaisa';
  }): Order => {
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const newOrderId = `KA-${randomSuffix}`;
    const trackingNo = `TRX-${Math.floor(100000000 + Math.random() * 900000000)}PK`;

    const freeShippingThreshold = storeSettings.freeShippingThreshold;
    const baseShipping = cartSubtotal >= freeShippingThreshold || appliedCoupon === 'FREESHIP' ? 0 : storeSettings.standardShippingFee;
    const discount = discountAmount;
    const grandTotal = Math.max(0, cartSubtotal + baseShipping - discount);

    const now = new Date();
    const formattedDate = `${now.getDate()} ${now.toLocaleString('default', { month: 'short' })} ${now.getFullYear()}, ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const newOrder: Order = {
      id: newOrderId,
      trackingNumber: trackingNo,
      customerName: orderInfo.customerName,
      email: orderInfo.email,
      phone: orderInfo.phone,
      city: orderInfo.city,
      address: orderInfo.address,
      postalCode: orderInfo.postalCode,
      notes: orderInfo.notes,
      items: [...cart],
      subtotal: cartSubtotal,
      shipping: baseShipping,
      discount: discount,
      total: grandTotal,
      paymentMethod: orderInfo.paymentMethod,
      paymentStatus: orderInfo.paymentMethod === 'card' ? 'paid' : 'pending',
      courierName: 'Trax / Leopards Express',
      orderStatus: 'placed',
      createdAt: formattedDate,
      estimatedDelivery: 'Within 2-3 Business Days',
      timeline: [
        {
          status: 'placed',
          label: 'Order Placed & Confirmed',
          description: 'Your order was received and queued for bespoke packaging.',
          timestamp: formattedDate,
          completed: true,
          current: true,
        },
        {
          status: 'packed',
          label: 'Quality Check & Satin Packaging',
          description: 'Each piece inspected for premium finish and packaged in gift box.',
          timestamp: 'Pending packaging',
          completed: false,
          current: false,
        },
        {
          status: 'dispatched',
          label: 'Dispatched with Courier',
          description: `Will be handed to Leopards / Trax Express with tracking ${trackingNo}.`,
          timestamp: 'Scheduled tomorrow morning',
          completed: false,
          current: false,
        },
        {
          status: 'out_for_delivery',
          label: `Out for Delivery in ${orderInfo.city}`,
          description: 'Local rider assigned for doorstep delivery with cash receipt.',
          timestamp: 'Pending dispatch',
          completed: false,
          current: false,
        },
        {
          status: 'delivered',
          label: 'Delivered',
          description: 'Package safely delivered to your doorstep.',
          timestamp: 'Pending delivery',
          completed: false,
          current: false,
        },
      ],
    };

    setOrders((prev) => [newOrder, ...prev]);
    clearCart();
    setAppliedCoupon(null);
    setTrackOrderId(newOrderId);
    return newOrder;
  };

  const getOrderById = (query: string): Order | undefined => {
    const q = query.trim().toUpperCase();
    if (!q) return undefined;
    return orders.find(
      (o) =>
        o.id.toUpperCase() === q ||
        o.trackingNumber.toUpperCase() === q ||
        o.phone.replace(/[^0-9]/g, '').includes(q.replace(/[^0-9]/g, ''))
    );
  };

  // Live order status advancement by Admin (updates customer tracking immediately)
  const updateOrderStatus = (
    orderId: string, 
    newStatus: OrderStatus, 
    newCourierName?: string, 
    newTrackingNo?: string
  ) => {
    const now = new Date();
    const formattedDate = `${now.getDate()} ${now.toLocaleString('default', { month: 'short' })} ${now.getFullYear()}, ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    setOrders((prev) =>
      prev.map((order) => {
        if (order.id !== orderId) return order;

        const courier = newCourierName || order.courierName;
        const tracking = newTrackingNo || order.trackingNumber;

        // Build updated timeline
        const statusOrder: OrderStatus[] = ['placed', 'packed', 'dispatched', 'out_for_delivery', 'delivered'];
        const targetIndex = statusOrder.indexOf(newStatus);

        const updatedTimeline = order.timeline.map((event) => {
          const eventIndex = statusOrder.indexOf(event.status);
          const isCompleted = eventIndex < targetIndex;
          const isCurrent = eventIndex === targetIndex;
          
          let timestamp = event.timestamp;
          if (isCurrent && (!timestamp || timestamp.includes('Pending'))) {
            timestamp = formattedDate;
          }

          let description = event.description;
          if (event.status === 'dispatched' && (courier || tracking)) {
            description = `Handed to ${courier} with waybill #${tracking}.`;
          }

          return {
            ...event,
            completed: isCompleted || (isCurrent && newStatus === 'delivered'),
            current: isCurrent && newStatus !== 'delivered',
            timestamp,
            description,
          };
        });

        return {
          ...order,
          orderStatus: newStatus,
          courierName: courier,
          trackingNumber: tracking,
          paymentStatus: newStatus === 'delivered' ? 'paid' : order.paymentStatus,
          timeline: updatedTimeline,
        };
      })
    );
  };

  const deleteOrder = (orderId: string) => {
    setOrders((prev) => prev.filter((o) => o.id !== orderId));
  };

  const openOrderTrackerWithId = (orderId?: string) => {
    if (orderId) {
      setTrackOrderId(orderId);
    }
    setIsTrackOrderOpen(true);
  };

  return (
    <ShopContext.Provider
      value={{
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        categories,
        addCategory,
        updateCategory,
        deleteCategory,
        storeSettings,
        updateStoreSettings,
        resetToDefaults,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartCount,
        cartSubtotal,
        coupons,
        appliedCoupon,
        discountAmount,
        applyCoupon,
        removeCoupon,
        addCoupon,
        toggleCoupon,
        deleteCoupon,
        wishlist,
        toggleWishlist,
        isInWishlist,
        orders,
        placeOrder,
        getOrderById,
        updateOrderStatus,
        deleteOrder,
        trackOrderId,
        setTrackOrderId,
        activeCategory,
        setActiveCategory,
        searchQuery,
        setSearchQuery,
        activeProduct,
        setActiveProduct,
        isCartOpen,
        setIsCartOpen,
        isWishlistOpen,
        setIsWishlistOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        isTrackOrderOpen,
        setIsTrackOrderOpen,
        openOrderTrackerWithId,
        isAdminMode,
        setIsAdminMode,
        isAdminAuthenticated,
        isAdminLoginOpen,
        setIsAdminLoginOpen,
        loginAdmin,
        logoutAdmin,
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};
