import React, { useState } from 'react';
import { X, Lock, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

export const AdminLoginModal: React.FC = () => {
  const { isAdminLoginOpen, setIsAdminLoginOpen, loginAdmin } = useShop();
  const [passcode, setPasscode] = useState('');
  const [error, setError] = useState('');

  if (!isAdminLoginOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const success = loginAdmin(passcode);
    if (!success) {
      setError('Invalid passcode. Use default password "admin123" to enter.');
    } else {
      setPasscode('');
    }
  };

  const handleQuickDemoLogin = () => {
    loginAdmin('admin123');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs transition-opacity"
        onClick={() => setIsAdminLoginOpen(false)}
      />

      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-4 bg-[#FAF9F6] border-b border-stone-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-800 flex items-center justify-center">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif text-base font-semibold text-stone-900">
                Komal Store Manager
              </h3>
              <p className="text-[11px] text-stone-500">Admin Control Panel</p>
            </div>
          </div>

          <button
            onClick={() => setIsAdminLoginOpen(false)}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-full hover:bg-stone-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <p className="text-xs text-stone-600 leading-relaxed">
            Enter your admin passcode to manage products, change rates, update images, add categories, and track customer orders.
          </p>

          <div>
            <label className="block text-xs font-medium text-stone-700 mb-1">
              Store Manager Passcode
            </label>
            <div className="relative">
              <input
                type="password"
                required
                value={passcode}
                onChange={(e) => {
                  setPasscode(e.target.value);
                  setError('');
                }}
                placeholder="Enter passcode (default: admin123)"
                autoFocus
                className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-300 rounded-xl outline-none focus:border-stone-800 focus:bg-white transition-all font-mono"
              />
            </div>

            {error && (
              <p className="text-xs text-rose-600 mt-1.5">{error}</p>
            )}
          </div>

          <button
            type="submit"
            className="w-full py-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer active:scale-98"
          >
            <span>Access Admin Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          {/* Quick Demo Access Button */}
          <div className="pt-3 border-t border-stone-100">
            <button
              type="button"
              onClick={handleQuickDemoLogin}
              className="w-full py-2 px-3 bg-rose-50 hover:bg-rose-100 text-rose-900 rounded-xl text-xs font-medium transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-rose-600" />
              <span>1-Click Store Owner Login (admin123)</span>
            </button>
          </div>

          <div className="flex items-center justify-center gap-1 text-[11px] text-stone-400 pt-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Connected directly to live store data</span>
          </div>
        </form>

      </div>
    </div>
  );
};
